#ifndef STATE_H
#define STATE_H
#include <vector>
#include <string>
const int SZ = 8;
typedef int fitness;
typedef std::string board;
typedef std::vector<board> population;
#endif
